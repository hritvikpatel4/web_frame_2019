from django.shortcuts import render, redirect
from .models import Signup, Login, Contact
from .forms import SignupForm, LoginForm, ContactForm

# Create your views here.
def login_new(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            post = form.save()
            return redirect('fronts')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

def contact_new(request):
    if request.method == "POST":
        form2 = ContactForm(request.POST)
        if form2.is_valid():
            post = form2.save()
            return redirect('fronts')
    else:
        form2 = ContactForm()
    return render(request, 'contact.html', {'form2': form2})

def fronts(request):
    return render(request, 'index.html', {})

def about(request):
    return render(request, 'about.html', {})

def people(request):
    return render(request, 'products.html', {})

def explore_new(request):
    return render(request, 'products.html', {})

def signup_new(request):
    if request.method == "POST":
        form1 = SignupForm(request.POST)
        if form1.is_valid():
            post = form1.save()
            return redirect('fronts')
    else:
        form1 = SignupForm()
    return render(request, 'signup.html', {'form1': form1})