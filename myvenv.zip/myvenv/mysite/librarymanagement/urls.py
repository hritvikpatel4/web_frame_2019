from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_new, name='login_new'),
    path('login/', views.signup_new, name='signup_new'),
    path('front/', views.fronts, name='fronts'),
    path('about/', views.about, name='about'),
    path('people/', views.people, name='people'),
    path('explore/', views.explore_new, name='explore_new'),
    path('contact/', views.contact_new, name='contact_new')
]